# Dashboard สถานที่การไฟฟ้า

หน้าเว็บ Dashboard แบบ Static สำหรับเผยแพร่ผ่าน GitHub Pages

## วิธีอัปโหลดเข้า repository

Repository: https://github.com/khet888/Dashboard-Treetriming

1. เปิด repository แล้วกด **Add file → Upload files**
2. ลากไฟล์ `index.html` และ `.nojekyll` จากชุดนี้ลงในโฟลเดอร์หลัก (root) ของ repository
3. กด **Commit changes** เพื่อบันทึกไฟล์
4. เข้า **Settings → Pages**
5. ในหัวข้อ **Build and deployment** เลือก **Deploy from a branch**
6. เลือก branch `main` และโฟลเดอร์ `/(root)` แล้วกด **Save**
7. รอ GitHub Pages เผยแพร่ แล้วเปิดลิงก์นี้:
   https://khet888.github.io/Dashboard-Treetriming/

หาก repository ใช้ branch อื่น ให้เลือก branch นั้นแทน `main` หากมี `index.html` อยู่แล้ว การอัปโหลดไฟล์นี้จะเป็นการแทนที่ไฟล์เดิม

## แหล่งข้อมูล

- `index.html` ฝังข้อมูล CSV ล่าสุดไว้เพื่อให้ Dashboard แสดงข้อมูลได้ทันที
- หน้าเว็บพยายามดึงข้อมูลจาก Google Sheets แท็บ Data (`gid=1`) เพิ่มเติมเมื่อเปิดใช้งาน
- การโหลดข้อมูลสดจาก Google Sheets ขึ้นอยู่กับสิทธิ์การเข้าถึงชีตและข้อจำกัดการเชื่อมต่อจากเบราว์เซอร์
- หากข้อมูลในชีตเปลี่ยนและการโหลดอัตโนมัติไม่สำเร็จ ให้อัปเดตข้อมูล CSV ที่ฝังใน `index.html` แล้ว commit ไฟล์ใหม่อีกครั้ง
